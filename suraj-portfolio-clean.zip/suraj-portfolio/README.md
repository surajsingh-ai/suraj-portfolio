# Suraj Singh - AI & Data Engineering Portfolio

This is the personal portfolio website of Suraj Singh, an aspiring AI & Data Engineering Professional. The website showcases his projects, skills, experience, and achievements.

## Features

- **Responsive Design:** Optimized for various devices and screen sizes.
- **Interactive UI:** Includes card effects, animations, and smooth scrolling.
- **Theme Toggle:** Switch between Light, Dark, and System themes.
- **Downloadable Resume:** Easily download Suraj Singh's resume in PDF format.
- **Project Showcase:** Detailed view of AI/ML and Data Engineering projects with bulleted descriptions.
- **Contact Information:** Quick access to LinkedIn, GitHub, Email, and Phone.

## Tech Stack

- **Frontend:** React.js
- **Styling:** Tailwind CSS
- **Animations:** Framer Motion
- **Icons:** Lucide React

## Setup and Installation (for local development)

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/surajsingh-ai/suraj-portfolio.git
    ```
2.  **Navigate to the project directory:**
    ```bash
    cd suraj-portfolio
    ```
3.  **Install dependencies:**
    ```bash
    npm install
    ```
4.  **Run the development server:**
    ```bash
    npm run dev
    ```
    The application will be available at `http://localhost:5173` (or another port if 5173 is in use).

## Contact

- **LinkedIn:** [Suraj Singh](https://www.linkedin.com/in/suraj-singh-28716829b)
- **GitHub:** [surajsingh-ai](https://github.com/surajsingh-ai)
- **Email:** surajsingh9170732347@gmail.com



