import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  Github, 
  Linkedin, 
  MapPin, 
  Calendar,
  Award,
  Code,
  Database,
  Brain,
  ChevronDown,
  ExternalLink,
  Sun,
  Moon,
  Monitor,
  Download
} from 'lucide-react';
import './App.css';

const Portfolio = () => {
  const [activeSection, setActiveSection] = useState('hero');
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    // Check for saved theme preference or default to 'dark'
    const savedTheme = localStorage.getItem('theme') || 'dark';
    setTheme(savedTheme);
    applyTheme(savedTheme);
  }, []);

  const applyTheme = (newTheme) => {
    const root = document.documentElement;
    
    if (newTheme === 'light') {
      root.style.setProperty('--background', 'oklch(0.98 0 0)');
      root.style.setProperty('--foreground', 'oklch(0.1 0 0)');
      root.style.setProperty('--card', 'oklch(1 0 0)');
      root.style.setProperty('--card-foreground', 'oklch(0.1 0 0)');
      root.style.setProperty('--border', 'oklch(0.9 0 0)');
      root.style.setProperty('--muted', 'oklch(0.95 0 0)');
      root.style.setProperty('--muted-foreground', 'oklch(0.5 0 0)');
    } else if (newTheme === 'dark') {
      root.style.setProperty('--background', 'oklch(0.05 0 0)');
      root.style.setProperty('--foreground', 'oklch(0.95 0 0)');
      root.style.setProperty('--card', 'oklch(0.1 0 0)');
      root.style.setProperty('--card-foreground', 'oklch(0.95 0 0)');
      root.style.setProperty('--border', 'oklch(0.3 0 0)');
      root.style.setProperty('--muted', 'oklch(0.2 0 0)');
      root.style.setProperty('--muted-foreground', 'oklch(0.7 0 0)');
    } else if (newTheme === 'system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      applyTheme(prefersDark ? 'dark' : 'light');
      return;
    }
  };

  const toggleTheme = (newTheme) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    applyTheme(newTheme);
  };

  const getThemeIcon = () => {
    switch (theme) {
      case 'light': return <Sun className="w-5 h-5" />;
      case 'dark': return <Moon className="w-5 h-5" />;
      case 'system': return <Monitor className="w-5 h-5" />;
      default: return <Moon className="w-5 h-5" />;
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'about', 'education', 'experience', 'projects', 'skills', 'achievements', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6
      }
    }
  };

  const projects = [
    {
      title: "AI-Powered Email Automation Agent",
      year: "July 2025 – Present",
      bullets: [
        "Developed a fully automated AI agent in n8n that sent over 500+ personalized cold emails using GPT-generated content.",
        "Achieved 80%+ email delivery rate, saving over 10 hours/week of manual effort and built a plug-and-play, zero-touch outreach system ideal for job applications and lead generation."
      ],
      tech: ["n8n", "OpenAI GPT API", "Google Sheets", "Gmail API"],
      icon: <Brain className="w-8 h-8" />
    },
    {
      title: "Face Recognition Attendance System",
      year: "2024",
      bullets: [
        "Built a real-time face recognition attendance tool using Python, OpenCV, and face recognition libraries.",
        "Automated CSV logging with date/time and improved efficiency via real-time image encoding."
      ],
      tech: ["Python", "OpenCV", "Pandas", "NumPy", "Face Recognition"],
      icon: <Brain className="w-8 h-8" />
    },
    {
      title: "Text-to-Speech Converter",
      year: "2024",
      bullets: [
        "Developed a TTS application using pyttsx3 for offline voice synthesis.",
        "Enabled GUI via Tkinter and customizable speed/voice for accessibility."
      ],
      tech: ["Python", "pyttsx3", "Tkinter"],
      icon: <Code className="w-8 h-8" />
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-2xl font-bold text-gradient"
            >
              Suraj Singh
            </motion.div>
            <div className="hidden md:flex space-x-8 items-center">
              {['About', 'Education', 'Experience', 'Projects', 'Skills', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`transition-colors duration-300 hover:text-primary ${
                    activeSection === item.toLowerCase() ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  {item}
                </button>
              ))}
              
              {/* Theme Toggle */}
              <div className="relative">
                <div className="flex items-center space-x-1 bg-card border border-border rounded-lg p-1">
                  {['light', 'dark', 'system'].map((themeOption) => (
                    <button
                      key={themeOption}
                      onClick={() => toggleTheme(themeOption)}
                      className={`p-2 rounded transition-all duration-300 ${
                        theme === themeOption 
                          ? 'bg-primary text-primary-foreground' 
                          : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                      }`}
                      title={`Switch to ${themeOption} theme`}
                    >
                      {themeOption === 'light' && <Sun className="w-4 h-4" />}
                      {themeOption === 'dark' && <Moon className="w-4 h-4" />}
                      {themeOption === 'system' && <Monitor className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="min-h-screen flex items-center justify-center hero-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23dc2626' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '60px 60px'
          }}></div>
        </div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="floating-animation">
              <h1 className="text-6xl md:text-8xl font-bold mb-4">
                <span className="text-gradient">Suraj Singh</span>
              </h1>
            </div>
            <div className="typewriter text-2xl md:text-3xl text-muted-foreground mb-8">
              AI & Data Engineering Professional
            </div>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Aspiring AI professional with expertise in ML, data engineering, and automation. 
              Passionate about solving real-world problems through innovative technology solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection('projects')}
                className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors pulse-red"
              >
                View My Work
              </motion.button>
              <motion.a
                href="/suraj.pdf"
                download="Suraj_Singh_Resume.pdf"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border border-primary text-primary px-8 py-3 rounded-lg font-semibold hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center"
              >
                <Download className="w-5 h-5 mr-2" /> Download Resume
              </motion.a>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection('contact')}
                className="border border-primary text-primary px-8 py-3 rounded-lg font-semibold hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                Get In Touch
              </motion.button>
            </div>
          </motion.div>
        </div>
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <ChevronDown className="w-8 h-8 text-primary" />
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-4xl mx-auto"
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              About Me
            </motion.h2>
            <motion.div variants={itemVariants} className="portfolio-card">
              <p className="text-lg leading-relaxed text-center">
                I'm an aspiring Artificial Intelligence professional currently pursuing B.Tech in Computer Science (AI) 
                at Bansal Institute of Engineering and Technology, Lucknow. With a strong foundation in machine learning, 
                data engineering, and automation, I'm passionate about leveraging technology to solve real-world problems. 
                Currently working as a Data Engineering Trainee at HCL Technologies, where I'm gaining hands-on experience 
                with ETL pipelines, data modeling, and data warehouse architecture.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 bg-card/50">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Education
            </motion.h2>
            <div className="max-w-4xl mx-auto space-y-6">
              {[
                {
                  degree: "B.Tech in Computer Science (AI)",
                  institution: "Bansal Institute of Engineering and Technology, Lucknow",
                  period: "2022–2026",
                  grade: "CGPA: 7.78 (73.91%)"
                },
                {
                  degree: "Intermediate (12th)",
                  institution: "Bal Nikunj Intercollege, Lucknow",
                  period: "2022",
                  grade: "Percentage: 77.80%"
                },
                {
                  degree: "High School (10th)",
                  institution: "Bal Nikunj Intercollege, Lucknow",
                  period: "2020",
                  grade: "Percentage: 80.00%"
                }
              ].map((edu, index) => (
                <motion.div key={index} variants={itemVariants} className="portfolio-card">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-primary mb-2">{edu.degree}</h3>
                      <p className="text-muted-foreground mb-1">{edu.institution}</p>
                      <p className="text-sm text-muted-foreground">{edu.grade}</p>
                    </div>
                    <div className="flex items-center text-muted-foreground mt-2 md:mt-0">
                      <Calendar className="w-4 h-4 mr-2" />
                      {edu.period}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Experience
            </motion.h2>
            <div className="max-w-4xl mx-auto">
              <motion.div variants={itemVariants} className="portfolio-card">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-2xl font-semibold text-primary mb-2">Data Engineering Trainee</h3>
                    <p className="text-lg text-muted-foreground mb-2">HCL Technologies</p>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-2" />
                    Oct 2024 – Present
                  </div>
                </div>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Gained hands-on experience with ETL pipelines, data modeling, and data warehouse architecture</li>
                  <li>• Developed scalable datasets using SQL and Python</li>
                  <li>• Contributed to real-time case studies reflecting industry-grade data workflows</li>
                </ul>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-card/50">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Projects
            </motion.h2>
            <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project, index) => (
                <motion.div key={index} variants={itemVariants} className="portfolio-card group">
                  <div className="flex items-center mb-4">
                    <div className="text-primary mr-4">{project.icon}</div>
                    <div>
                      <h3 className="text-xl font-semibold text-primary group-hover:text-primary-foreground transition-colors">
                        {project.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{project.year}</p>
                    </div>
                  </div>
                  <ul className="list-disc list-inside text-muted-foreground mb-4 space-y-1">
                    {project.bullets.map((bullet, bulletIndex) => (
                      <li key={bulletIndex}>{bullet}</li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech, techIndex) => (
                      <span key={techIndex} className="skill-tag">
                        {tech}
                      </span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Technical Skills
            </motion.h2>
            <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  category: "Languages",
                  skills: ["Python", "Java", "C++", "HTML/CSS"],
                  icon: <Code className="w-8 h-8" />
                },
                {
                  category: "Tools",
                  skills: ["Git", "GitHub", "VS Code", "Jupyter", "Google Colab", "PyCharm", "R Studio"],
                  icon: <Database className="w-8 h-8" />
                },
                {
                  category: "Databases",
                  skills: ["MySQL", "MongoDB"],
                  icon: <Database className="w-8 h-8" />
                },
                {
                  category: "Libraries",
                  skills: ["Pandas", "NumPy", "Matplotlib", "OpenCV", "Flask", "PySpark"],
                  icon: <Brain className="w-8 h-8" />
                }
              ].map((skillGroup, index) => (
                <motion.div key={index} variants={itemVariants} className="portfolio-card">
                  <div className="flex items-center mb-4">
                    <div className="text-primary mr-3">{skillGroup.icon}</div>
                    <h3 className="text-lg font-semibold text-primary">{skillGroup.category}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {skillGroup.skills.map((skill, skillIndex) => (
                      <span key={skillIndex} className="skill-tag">
                        {skill}
                      </span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Achievements Section */}
      <section id="achievements" className="py-20 bg-card/50">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Achievements
            </motion.h2>
            <div className="max-w-4xl mx-auto space-y-6">
              {[
                {
                  title: "1st Prize – Tech-Expo (IIT Guwahati)",
                  description: "Team Avinya",
                  date: "Aug 2024"
                },
                {
                  title: "3rd Rank – Hackathon 3.0 (SRMS Bareilly)",
                  description: "36-Hour Hackathon",
                  date: "2024"
                },
                {
                  title: "2nd Place – College Project Competition",
                  description: "Smart Parking Management System",
                  date: "2024"
                }
              ].map((achievement, index) => (
                <motion.div key={index} variants={itemVariants} className="portfolio-card">
                  <div className="flex items-start">
                    <Award className="w-6 h-6 text-primary mr-4 mt-1 flex-shrink-0" />
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-primary mb-1">{achievement.title}</h3>
                      <p className="text-muted-foreground mb-1">{achievement.description}</p>
                      <p className="text-sm text-muted-foreground">{achievement.date}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-12 text-gradient">
              Get In Touch
            </motion.h2>
            <div className="max-w-4xl mx-auto">
              <motion.div variants={itemVariants} className="portfolio-card text-center">
                <p className="text-lg text-muted-foreground mb-8">
                  I'm always open to discussing new opportunities, collaborations, or just having a chat about technology and AI.
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <a
                    href="mailto:surajsingh9170732347@gmail.com"
                    className="flex items-center justify-center p-4 border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-all duration-300 group"
                  >
                    <Mail className="w-6 h-6 text-primary mr-3 group-hover:scale-110 transition-transform" />
                    <span>surajsingh9170732347@gmail.com</span>
                  </a>
                  <a
                    href="tel:+919170732347"
                    className="flex items-center justify-center p-4 border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-all duration-300 group"
                  >
                    <Phone className="w-6 h-6 text-primary mr-3 group-hover:scale-110 transition-transform" />
                    <span>+91-9170732347</span>
                  </a>
                  <a
                    href="https://www.linkedin.com/in/suraj-singh-28716829b"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center p-4 border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-all duration-300 group"
                  >
                    <Linkedin className="w-6 h-6 text-primary mr-3 group-hover:scale-110 transition-transform" />
                    <span>LinkedIn Profile</span>
                    <ExternalLink className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                  <a
                    href="https://github.com/surajsingh-ai"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center p-4 border border-border rounded-lg hover:border-primary hover:bg-primary/10 transition-all duration-300 group"
                  >
                    <Github className="w-6 h-6 text-primary mr-3 group-hover:scale-110 transition-transform" />
                    <span>GitHub Profile</span>
                    <ExternalLink className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-card border-t border-border">
        <div className="container mx-auto px-6 text-center">
          <p className="text-muted-foreground">
            © 2024 Suraj Singh. Built with React and passion for technology.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;

